from django.contrib import admin

from games_play.models import ProfileModel, GameModel

admin.site.register(ProfileModel)
admin.site.register(GameModel)
